# CAMPUS DRIP — Production Starter v2

Android + iPhone shopping app starter for Fashion, Football and Cricket.

## Included
- Flutter mobile starter
- Node.js API with product and order endpoints
- Environment template for database/payment keys
- PostgreSQL starter schema
- Admin-panel roadmap

## Important
This is a development starter, not a published live app. Before launch, add authentication, real database queries, Razorpay integration, COD rules, courier API, admin authentication, privacy policy, testing, hosting and store release signing.
