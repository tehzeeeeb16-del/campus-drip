# Setup

## Backend
```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

## Database
Create a PostgreSQL database and run:
```bash
psql "$DATABASE_URL" -f database/schema.sql
```

## Mobile
```bash
cd mobile
flutter pub get
flutter run
```

For a physical phone, replace localhost in the API URL with your computer's local network IP.


## Clothing catalog added
Run from the `mobile` folder:

```bash
flutter pub get
flutter run
```
