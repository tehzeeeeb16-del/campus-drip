# CAMPUS DRIP Admin Panel

Planned production panel: product CRUD, stock, orders, payment status, courier tracking and coupons.

Recommended next setup: React + Vite + Tailwind + role-based authentication.
