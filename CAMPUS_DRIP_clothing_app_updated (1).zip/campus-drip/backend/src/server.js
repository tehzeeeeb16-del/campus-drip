import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import crypto from 'node:crypto';

const app = express();
app.use(cors());
app.use(helmet());
app.use(express.json());
app.use(morgan('dev'));

const products = [
  { id: 'p1', name: 'Classic White Shirt', category: 'Shirts', price: 999, stock: 100 },
  { id: 'p2', name: 'Black T-Shirt', category: 'T-Shirts', price: 599, stock: 100 },
  { id: 'p3', name: 'White T-Shirt', category: 'T-Shirts', price: 599, stock: 100 },
  { id: 'p4', name: 'Grey Hoodie', category: 'Hoodies', price: 1299, stock: 60 },
  { id: 'p5', name: 'Black Hoodie', category: 'Hoodies', price: 1299, stock: 60 },
  { id: 'p6', name: 'Light Blue Jeans', category: 'Pants', price: 1199, stock: 80 },
  { id: 'p7', name: 'Black Jeans', category: 'Pants', price: 1199, stock: 80 },
  { id: 'p8', name: 'Cargo Pants', category: 'Pants', price: 1099, stock: 80 },
  { id: 'p9', name: 'Jogger Pants', category: 'Pants', price: 899, stock: 80 },
  { id: 'p10', name: 'Beige Trousers', category: 'Pants', price: 999, stock: 80 },
  { id: 'p11', name: 'Black Trousers', category: 'Pants', price: 999, stock: 80 },
  { id: 'p12', name: 'White Sneakers', category: 'Shoes', price: 1499, stock: 70 },
  { id: 'p13', name: 'Black Sneakers', category: 'Shoes', price: 1499, stock: 70 },
  { id: 'p14', name: 'High Top Sneakers', category: 'Shoes', price: 1799, stock: 70 },
  { id: 'p15', name: 'Running Shoes', category: 'Shoes', price: 1599, stock: 70 },
  { id: 'p16', name: 'Slip-On Shoes', category: 'Shoes', price: 999, stock: 70 },
  { id: 'p17', name: 'Black Boots', category: 'Shoes', price: 1999, stock: 50 }
];

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'CAMPUS DRIP' }));
app.get('/api/products', (_req, res) => res.json({ items: products }));

app.post('/api/orders', (req, res) => {
  const { customer, items, address, paymentMethod } = req.body;
  if (!customer?.name || !customer?.phone || !Array.isArray(items) || !items.length || !address || !['online', 'cod'].includes(paymentMethod)) {
    return res.status(400).json({ message: 'customer, items, address and valid paymentMethod are required' });
  }
  const total = items.reduce((sum, item) => sum + Number(item.price || 0) * Number(item.quantity || 1), 0);
  const orderId = `CD-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  res.status(201).json({ orderId, status: 'placed', paymentMethod, total });
});

const port = process.env.PORT || 4000;
app.listen(port, () => console.log(`CAMPUS DRIP API running on http://localhost:${port}`));
